[hr]
[center][color=teal][size=16pt][b]Simple Hide BBC - Hide the Goodies from Lurkers[/b][/size][/color]
[u](For SMF 2.0.x)[/u]
Mod by xPandax | [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=158159]Other Mods[/url] by xPandax
[/center]
[hr]
[center][url=http://custom.simplemachines.org/mods/index.php?mod=3745]Link to Mod[/url] | [url]Support Thread for this Mod[/url][/center]


[color=purple][size=12pt][b]Features[/b][/size][/color]
This mod adds a "hide" BBC which can be used to hide the goodies from lurkers. This mod can be used to share contents like

1) PSN/XBL/Steam and other gaming related codes
2) Beta access codes
3) Discount coupons for online shopping websites
4) Gift Cards

and more such stuff like that. Only the members deserve access to such valuable content.

Using this "hide" BBC, entire post or selected content in a post can be hidden from guests. Guests and users who have not logged into the forum will see the following message,

[color=red]Sorry, only registered users can see this content.[/color] Please Login or Register.


[color=purple][size=12pt][b]How-To[/b][/size][/color]
Just wrap the content within [color=blue][hide][/hide][/color] tags.


[color=purple][size=12pt][b]Supported Themes[/b][/size][/color]
Works on almost all the themes without any custom edits!


[color=purple][size=12pt][b]Supported SMF Versions[/b][/size][/color]
Tested on fresh installation of 2.0.4.


[color=purple][size=12pt][b]Supported Languages[/b][/size][/color]
[list]
[li]English[/li]
[/list]
Translations to other languages are welcome. Please post them in this [url]Support Thread for this Mod[/url].


[color=purple][size=12pt][b]Support[/b][/size][/color]
If you need support with this mod, please use the [url]Support Thread for this Mod[/url].

 
[color=purple][size=12pt][b]Changelog[/b][/size][/color]
[b]v1.0[/b] - Initial release.


[hr]
[center]
This is free and unencumbered public domain software. For more information, see [url=http://unlicense.org/]http://unlicense.org/[/url] or the accompanying UNLICENSE file.
[/center]
